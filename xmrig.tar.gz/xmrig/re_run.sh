#!/bin/bash

# Cek dan bersihkan sesi screen yang lama
echo "Cek dan bersihkan sesi screen yang lama..."
screen -ls
screen -wipe

# Loop tak terbatas untuk menjalankan mining dengan jeda
echo "Memulai loop mining dengan jeda..."
while true; do
    # Hentikan proses mining jika masih berjalan
    echo "Menghentikan proses mining yang lama..."
    screen -S github -X quit
    sleep 5  # Tunggu sebentar agar proses benar-benar mati
    
    # Jalankan mining di screen 'github'
    echo "Memulai mining di screen 'github'..."
    screen -dmS github ./xmrig --config=config.json --threads=3
    echo "Mining berjalan..."
    
    # Tunggu selama 58 menit dan pastikan xmrig tetap berjalan
    for i in {1..58}; do
        sleep 60  # Tidur 1 menit
        if ! screen -list | grep -q "github"; then
            echo "Mining berhenti lebih awal, memulai ulang..."
            break
        fi
    done
    
    # Hentikan proses mining
    echo "Menghentikan mining untuk jeda..."
    screen -S github -X quit
    
    # Jeda selama 5 menit
    echo "Jeda selama 5 menit..."
    sleep 300  # 5 menit dalam detik

done
